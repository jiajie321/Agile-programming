<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require 'db_connection.php';

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $form_to_show = 'login'; // Default

    // Function to reset password (no hashing yet; keep same style as your current system)
    function resetPassword($conn, $user_name, $new_password) {
        $stmt = $conn->prepare("UPDATE register SET password = :new_password WHERE user_name = :user_name");
        $stmt->bindParam(':new_password', $new_password);
        $stmt->bindParam(':user_name', $user_name);
        $stmt->execute();
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $action = $_POST['action'] ?? '';

        $user_name    = trim($_POST['user_name'] ?? '');
        $password     = $_POST['password'] ?? '';
        $full_name    = trim($_POST['full_name'] ?? '');
        $phone_number = trim($_POST['phone_number'] ?? '');
        $email        = trim($_POST['email'] ?? '');
        $user_type    = $_POST['user_type'] ?? ''; // resident / nonresident
        $block        = trim($_POST['block'] ?? '');

        $new_password = $_POST['new_password'] ?? '';

        if ($action == "register") {
            // Basic validation
            if ($user_type === 'resident' && $block === '') {
                $register_error = "Block is required for residents.";
                $form_to_show = 'signup';
            } else {
                // Check duplicate username
                $stmt = $conn->prepare("SELECT COUNT(*) FROM register WHERE user_name = :user_name");
                $stmt->bindParam(':user_name', $user_name);
                $stmt->execute();
                $count = (int)$stmt->fetchColumn();

                if ($count > 0) {
                    $register_error = "Username already exists. Please choose a different username.";
                    $form_to_show = 'signup';
                } else {
                    // ✅ Verification logic:
                    // - resident => pending (admin verify)
                    // - nonresident => verified (can login)
                    $is_verified = 1;
                    $verify_status = 'verified';

                    if ($user_type === 'resident') {
                        $is_verified = 0;
                        $verify_status = 'pending';
                    }

                    // ✅ Insert with new columns
                    $stmt = $conn->prepare("
                        INSERT INTO register
                        (user_name, password, full_name, phone_number, email, block, type, is_verified, verify_status, verified_at)
                        VALUES
                        (:user_name, :password, :full_name, :phone_number, :email, :block, :type, :is_verified, :verify_status, NULL)
                    ");

                    $stmt->bindParam(':user_name', $user_name);
                    $stmt->bindParam(':password', $password);
                    $stmt->bindParam(':full_name', $full_name);
                    $stmt->bindParam(':phone_number', $phone_number);
                    $stmt->bindParam(':email', $email);
                    $stmt->bindParam(':block', $block);
                    $stmt->bindParam(':type', $user_type);
                    $stmt->bindParam(':is_verified', $is_verified, PDO::PARAM_INT);
                    $stmt->bindParam(':verify_status', $verify_status);
                    $stmt->execute();

                    // Success message depends on type
                    if ($user_type === 'resident') {
                        $success = "Registration submitted. Your account is pending admin verification.";
                    } else {
                        $success = "Registration successful. You can now log in.";
                    }

                    $form_to_show = 'signup';
                }
            }
        } elseif ($action == "login") {
            // ✅ Login checks
            $stmt = $conn->prepare("SELECT * FROM register WHERE user_name = :user_name AND password = :password");
            $stmt->bindParam(':user_name', $user_name);
            $stmt->bindParam(':password', $password);
            $stmt->execute();
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user) {
                // ✅ Block resident login if pending
                if ($user['type'] === 'resident' && (int)$user['is_verified'] === 0) {
                    $login_error = "Your account is pending admin verification. Please wait for approval.";
                    $form_to_show = 'login';
                } elseif (isset($user['verify_status']) && $user['verify_status'] === 'rejected') {
                    $login_error = "Your registration was rejected. Please contact the management office.";
                    $form_to_show = 'login';
                } else {
                    // Successful login
                    $_SESSION['register_id'] = $user['id'];
                    $_SESSION['user_name'] = $user['user_name'];
                    $_SESSION['full_name'] = $user['full_name'];
                    $_SESSION['phone_number'] = $user['phone_number'];
                    $_SESSION['email'] = $user['email'];
                    $_SESSION['block'] = $user['block'];
                    $_SESSION['user_type'] = $user['type'];

                    header("Location: resident_nonresident.php");
                    exit;
                }
            } else {
                $login_error = "Invalid username or password";
                $form_to_show = 'login';
            }
        } elseif ($action == "forgot_password") {
            $user_name = trim($_POST['user_name'] ?? '');
            $email = trim($_POST['email'] ?? '');

            $stmt = $conn->prepare("SELECT * FROM register WHERE user_name = :user_name AND email = :email");
            $stmt->bindParam(':user_name', $user_name);
            $stmt->bindParam(':email', $email);
            $stmt->execute();
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user) {
                $form_to_show = 'new_password';
                $_SESSION['reset_user_name'] = $user_name;
            } else {
                $reset_error = "Username and email do not match our records.";
                $form_to_show = 'forgot_password';
            }
        } elseif ($action == "new_password") {
            if (isset($_SESSION['reset_user_name'])) {
                $user_name = $_SESSION['reset_user_name'];
                $new_password = $_POST['new_password'];

                resetPassword($conn, $user_name, $new_password);
                $success = "Your password has been reset. You can now log in.";
                $form_to_show = 'login';
                unset($_SESSION['reset_user_name']);
            } else {
                $reset_error = "Session expired. Please try again.";
                $form_to_show = 'forgot_password';
            }
        }
    }
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html>

<head>
    <title>Register/Login</title>
    <link rel="stylesheet" href="css/login_resident.css" />
</head>

<body>
    <div class="container">
        <div class="toggle-buttons">
            <button id="loginBtn" type="button" onclick="toggleForm('login')">Login</button>
            <button id="signupBtn" type="button" onclick="toggleForm('signup')">Signup</button>
        </div>

        <!-- Login Form -->
        <form id="loginForm" method="post" action="">
            <input type="hidden" name="action" value="login">
            <h2>Login Form</h2>

            <label for="user_name_login">Username:</label>
            <input type="text" id="user_name_login" name="user_name" required>

            <label for="password_login">Password:</label>
            <input type="password" id="password_login" name="password" required>

            <label>
                <input type="checkbox" onclick="togglePasswordVisibility('password_login')"> Show Password
            </label>

            <input type="submit" value="Login">

            <?php if (isset($login_error)): ?>
                <p class="error"><?php echo $login_error; ?></p>
            <?php endif; ?>

            <div class="links">
                <p>Don't have an account? <a href="javascript:void(0)" onclick="toggleForm('signup')">Please register</a>.</p>
                <p><a href="javascript:void(0)" onclick="toggleForm('forgot_password')">Forgot Password?</a></p>
            </div>
        </form>

        <!-- Signup Form -->
        <form id="signupForm" method="post" action="">
            <input type="hidden" name="action" value="register">
            <h2>Signup Form</h2>

            <label for="full_name">Full Name:</label>
            <input type="text" id="full_name" name="full_name" required>

            <label for="phone_number">Phone Number:</label>
            <input type="text" id="phone_number" name="phone_number" required>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>

            <label for="user_name_signup">Username:</label>
            <input type="text" id="user_name_signup" name="user_name" required>

            <label for="password_signup">Password:</label>
            <input type="password" id="password_signup" name="password" required>

            <label>
                <input type="checkbox" onclick="togglePasswordVisibility('password_signup')"> Show Password
            </label>

            <div id="block_field">
                <label for="block">Block:</label>
                <input type="text" id="block" name="block">
            </div>

            <label for="user_type">User Type:</label>
            <select id="user_type" name="user_type" onchange="toggleBlockField()" required>
                <option value="resident">Resident</option>
                <option value="nonresident">Non-resident</option>
            </select>

            <input type="submit" value="Signup">

            <?php if (isset($register_error)): ?>
                <p class="error"><?php echo $register_error; ?></p>
            <?php endif; ?>

            <?php if (isset($success) && $form_to_show == 'signup'): ?>
                <p class="success"><?php echo $success; ?></p>
            <?php endif; ?>
        </form>

        <!-- Forgot Password Form -->
        <form id="forgotPasswordForm" method="post" action="">
            <input type="hidden" name="action" value="forgot_password">
            <h2>Forgot Password</h2>

            <label for="user_name_forgot">Username:</label>
            <input type="text" id="user_name_forgot" name="user_name" required>

            <label for="email_forgot">Registered Email:</label>
            <input type="email" id="email_forgot" name="email" required>

            <input type="submit" value="Submit">

            <?php if (isset($reset_error)): ?>
                <p class="error"><?php echo $reset_error; ?></p>
            <?php endif; ?>
        </form>

        <!-- New Password Form -->
        <form id="newPasswordForm" method="post" action="">
            <input type="hidden" name="action" value="new_password">
            <h2>Set New Password</h2>

            <label for="new_password">New Password:</label>
            <input type="password" id="new_password" name="new_password" required>

            <label>
                <input type="checkbox" onclick="togglePasswordVisibility('new_password')"> Show Password
            </label>

            <input type="submit" value="Set Password">
        </form>
    </div>

    <script>
    function toggleForm(formType) {
        var loginForm = document.getElementById("loginForm");
        var signupForm = document.getElementById("signupForm");
        var forgotPasswordForm = document.getElementById("forgotPasswordForm");
        var newPasswordForm = document.getElementById("newPasswordForm");
        var loginBtn = document.getElementById("loginBtn");
        var signupBtn = document.getElementById("signupBtn");

        loginForm.classList.remove('active');
        signupForm.classList.remove('active');
        forgotPasswordForm.classList.remove('active');
        newPasswordForm.classList.remove('active');

        loginBtn.classList.remove('active');
        signupBtn.classList.remove('active');

        if (formType === 'login') {
            loginForm.classList.add('active');
            loginBtn.classList.add('active');
        } else if (formType === 'signup') {
            signupForm.classList.add('active');
            signupBtn.classList.add('active');
        } else if (formType === 'forgot_password') {
            forgotPasswordForm.classList.add('active');
        } else if (formType === 'new_password') {
            newPasswordForm.classList.add('active');
        }
    }

    function toggleBlockField() {
        var userType = document.getElementById("user_type").value;
        var blockField = document.getElementById("block_field");
        if (userType === "resident") {
            blockField.style.display = "block";
        } else {
            blockField.style.display = "none";
            document.getElementById("block").value = ""; // clear block for nonresident
        }
    }

    function togglePasswordVisibility(id) {
        var input = document.getElementById(id);
        input.type = (input.type === "password") ? "text" : "password";
    }

    document.addEventListener("DOMContentLoaded", function() {
        var formToShow = "<?php echo $form_to_show; ?>";
        toggleForm(formToShow);
        toggleBlockField();
    });
    </script>

    <footer>
        <p>&copy; <?= date('Y') ?> Condominium Facilities Booking System. All rights reserved. | Created by JiaJie</p>
    </footer>
</body>
</html>