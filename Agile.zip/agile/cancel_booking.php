<?php
require 'db_connection.php';
session_start();

header_remove("X-Powered-By");
date_default_timezone_set("Asia/Kuala_Lumpur");

/**
 * =========================================================
 * ✅ MUST LOGIN (this page uses full_name as the main identity)
 * =========================================================
 */
if (!isset($_SESSION['full_name'])) {
    die("User not logged in or session expired.");
}

$full_name = trim((string)$_SESSION['full_name']);

/**
 * =========================================================
 * ✅ CONFIG: Which statuses are allowed to be cancelled?
 * - Based on your latest logic:
 *   - resident: booked -> confirmed (no payment)
 *   - nonresident: booked -> paid (or you may change to confirmed too)
 *
 * If your system uses "paid" for nonresident, keep it here.
 * If you changed payment to "confirmed", you can remove "paid".
 * =========================================================
 */
$CANCEL_ALLOWED_STATUSES = ['booked', 'confirmed', 'paid'];

/**
 * =========================================================
 * ✅ AJAX CANCEL (returns JSON)
 * =========================================================
 */
if ($_SERVER['REQUEST_METHOD'] === 'POST'
    && isset($_POST['action']) && $_POST['action'] === 'cancel_booking'
) {
    header('Content-Type: application/json; charset=utf-8');

    $booking_id = isset($_POST['booking_id']) ? (int)$_POST['booking_id'] : 0;
    if ($booking_id <= 0) {
        echo json_encode(['error' => 'Invalid booking ID.']);
        exit;
    }

    try {
        // ✅ Only cancel user's own booking (match register.full_name)
        // ✅ Only cancel if it is in allowed statuses
        // ✅ Only cancel if it is in the future
        $placeholders = implode(",", array_fill(0, count($CANCEL_ALLOWED_STATUSES), "?"));

        $sql = "
            UPDATE booking b
            INNER JOIN register r ON b.register_id = r.id
            SET b.status = 'cancelled'
            WHERE b.id = ?
              AND TRIM(r.full_name) = TRIM(?)
              AND b.status IN ($placeholders)
              AND (
                    b.booking_date > CURDATE()
                 OR (b.booking_date = CURDATE() AND b.booking_time > CURTIME())
              )
        ";

        $params = [];
        $params[] = $booking_id;
        $params[] = $full_name;
        foreach ($CANCEL_ALLOWED_STATUSES as $s) $params[] = $s;

        $stmt = $conn->prepare($sql);
        $stmt->execute($params);

        if ($stmt->rowCount() > 0) {
            echo json_encode(['success' => 'Booking cancelled successfully.']);
        } else {
            echo json_encode(['error' => 'Failed to cancel (not found / not yours / already cancelled / not cancellable).']);
        }
        exit;

    } catch (PDOException $e) {
        echo json_encode(['error' => 'DB Error: ' . $e->getMessage()]);
        exit;
    }
}

/**
 * =========================================================
 * ✅ NORMAL PAGE LOAD: Fetch upcoming cancellable bookings
 * =========================================================
 */
try {
    $placeholders = implode(",", array_fill(0, count($CANCEL_ALLOWED_STATUSES), "?"));

    $sql = "
        SELECT b.id, b.facility_id, b.booking_date, b.booking_time, b.status
        FROM booking b
        INNER JOIN register r ON b.register_id = r.id
        WHERE TRIM(r.full_name) = TRIM(?)
          AND (
                b.booking_date > CURDATE()
             OR (b.booking_date = CURDATE() AND b.booking_time > CURTIME())
          )
          AND b.status IN ($placeholders)
        ORDER BY b.booking_date, b.booking_time
    ";

    $params = [];
    $params[] = $full_name;
    foreach ($CANCEL_ALLOWED_STATUSES as $s) $params[] = $s;

    $stmt = $conn->prepare($sql);
    $stmt->execute($params);
    $bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Facility name map
    $stmt2 = $conn->prepare("SELECT id, name FROM Facility");
    $stmt2->execute();
    $facilities = $stmt2->fetchAll(PDO::FETCH_ASSOC);
    $facilityNames = array_column($facilities, 'name', 'id');

} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cancel Booking</title>
    <link rel="stylesheet" href="css/cancel_booking.css" />
</head>

<header>
    <div class="navbar">
        <a href="resident_nonresident.php">Home Page</a>
        <a href="cancel_booking.php">Cancel Booking</a>
        <a href="view_booking_history.php">View Booking History</a>
        <a href="submit_feedback.php">Feedback</a>
        <a href="about_us.php">About Us</a>
        <a href="announcements.php">Announcements</a>

        <div class="welcome" style="position: relative;">
            <span id="user-name" style="cursor: pointer;">
                Welcome, <?= htmlspecialchars($_SESSION['full_name']); ?>
            </span>
            <a href="logouts.php" style="color: white; margin-left: 5px;">Log Out</a>
            <a href="reset_password.php" id="reset-password">Reset Password</a>
        </div>
    </div>
</header>

<body>
    <div class="header2">
        <h1>Cancel Booking</h1>
    </div>

    <div class="container">
        <p class="note">Note: No refund will be provided for cancelled bookings.</p>

        <?php if (!empty($bookings)): ?>
            <table>
                <thead>
                    <tr>
                        <th>Facility</th>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($bookings as $booking): ?>
                        <tr>
                            <td><?= htmlspecialchars($facilityNames[$booking['facility_id']] ?? 'Facility') ?></td>
                            <td><?= htmlspecialchars($booking['booking_date']) ?></td>
                            <td><?= htmlspecialchars($booking['booking_time']) ?></td>
                            <td><?= htmlspecialchars($booking['status']) ?></td>
                            <td>
                                <button type="button"
                                        class="cancel-button"
                                        data-booking-id="<?= (int)$booking['id'] ?>">
                                    Cancel
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No upcoming bookings to cancel.</p>
        <?php endif; ?>
    </div>

    <!-- Confirmation Modal -->
    <div id="confirmationModal" class="modal">
        <div class="modal-content">
            <p>Are you sure you want to cancel this booking? No refunds will be provided.</p>
            <div class="modal-buttons">
                <button id="confirmButton" class="modal-button">Yes, Cancel</button>
                <button id="cancelButton" class="modal-button">No, Go Back</button>
            </div>
        </div>
    </div>

    <!-- Alert Modal -->
    <div id="customAlertModal" class="modal">
        <div class="modal-content">
            <p id="alertMessage"></p>
            <button id="closeAlertButton" class="modal-button">OK</button>
        </div>
    </div>

    <footer>
        <p>&copy; <?= date('Y') ?> Condominium Facilities Booking System. All rights reserved. | Created by JiaJie</p>
    </footer>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const modal = document.getElementById("confirmationModal");
    const alertModal = document.getElementById("customAlertModal");
    const alertMessage = document.getElementById("alertMessage");
    const closeAlertButton = document.getElementById("closeAlertButton");
    const confirmButton = document.getElementById("confirmButton");
    const cancelButton = document.getElementById("cancelButton");

    let currentBookingId = null;

    document.querySelectorAll('.cancel-button').forEach(btn => {
        btn.addEventListener('click', function () {
            currentBookingId = this.dataset.bookingId;
            modal.style.display = "flex";
        });
    });

    confirmButton.onclick = function () {
        modal.style.display = "none";

        const xhr = new XMLHttpRequest();
        xhr.open("POST", "cancel_booking.php", true);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

        xhr.onload = function () {
            try {
                const response = JSON.parse(xhr.responseText);
                if (response.success) {
                    alertMessage.textContent = response.success;
                    alertModal.style.display = "flex";
                    setTimeout(() => location.reload(), 800);
                } else {
                    alertMessage.textContent = response.error || "An error occurred.";
                    alertModal.style.display = "flex";
                }
            } catch (e) {
                alertMessage.textContent = "Invalid server response.";
                alertModal.style.display = "flex";
            }
        };

        xhr.send("action=cancel_booking&booking_id=" + encodeURIComponent(currentBookingId));
    };

    cancelButton.onclick = function () {
        modal.style.display = "none";
    };

    closeAlertButton.onclick = function () {
        alertModal.style.display = "none";
    };

    window.onclick = function (event) {
        if (event.target === modal || event.target === alertModal) {
            modal.style.display = "none";
            alertModal.style.display = "none";
        }
    };
});
</script>
</body>
</html>