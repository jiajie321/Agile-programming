<?php
require 'db_connection.php';
require __DIR__ . '/PHPMailer-master/PHPMailer-master/src/PHPMailer.php';
require __DIR__ . '/PHPMailer-master/PHPMailer-master/src/SMTP.php';
require __DIR__ . '/PHPMailer-master/PHPMailer-master/src/Exception.php';
require __DIR__ . '/phpqrcode-2010100721_1.1.4/phpqrcode/qrlib.php';
require __DIR__ . '/FPDF-master/FPDF-master/fpdf.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

session_start();

$paymentMessage = '';

// ✅ 必须有 booking_id & facility_id
if (!isset($_SESSION['booking_id']) || !isset($_SESSION['facility_id'])) {
    die("Invalid booking or facility ID.");
}

$booking_id  = (int)$_SESSION['booking_id'];
$facility_id = (int)$_SESSION['facility_id'];

/**
 * =========================================================
 * ✅ Gmail SMTP Config（请改成你自己的 App Password）
 * =========================================================
 */
$gmailUser = 'odintan93@gmail.com';
$gmailAppPassword = 'xhty lfgu wsut qqtd';
$fromName = 'agile project';

/**
 * =========================================================
 * ✅ Helper: QR
 * =========================================================
 */
function generateQRCode($data, $filename) {
    $tempDir = __DIR__ . '/temp/';
    if (!file_exists($tempDir)) {
        mkdir($tempDir, 0777, true);
    }
    $filePath = $tempDir . $filename;
    QRcode::png($data, $filePath, QR_ECLEVEL_L, 5);
    return $filePath;
}

/**
 * =========================================================
 * ✅ Helper: Email (PHPMailer)
 * =========================================================
 */
function sendEmail($to, $subject, $body, $attachments = []) {
    global $gmailUser, $gmailAppPassword, $fromName;

    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = $gmailUser;
        $mail->Password = $gmailAppPassword;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom($gmailUser, $fromName);
        $mail->addAddress($to);

        foreach ($attachments as $attachment) {
            if (!empty($attachment) && file_exists($attachment)) {
                $mail->addAttachment($attachment);
            }
        }

        // ✅ signature image (optional)
        $sigPath = 'C:/xampp/htdocs/fyp/images/jiajie.jpg';
        if (file_exists($sigPath)) {
            $mail->AddEmbeddedImage($sigPath, 'signature_image', 'jiajie.jpg');
            $signatureHtml = "
                <div>
                    <p>Signature: <span style='font-style:italic;'>Tan</span></p>
                    <p>Name: JiaJie</p>
                    <img src='cid:signature_image' alt='Signature Image' style='width: 200px; height: auto;'>
                </div>
            ";
        } else {
            $signatureHtml = "<p>Regards,<br>JiaJie</p>";
        }

        $mail->isHTML(true);
        $mail->Subject = $subject;

        $mail->Body = "
        <html>
        <body>
            $body
            $signatureHtml
        </body>
        </html>";

        $mail->send();
        return true;

    } catch (Exception $e) {
        error_log("Email failed: {$mail->ErrorInfo}");
        return false;
    }
}

/**
 * =========================================================
 * ✅ Receipt (FPDF)
 * =========================================================
 */
function generateReceipt($booking, $facility_name) {
    $pdf = new FPDF();
    $pdf->AddPage();

    $pdf->SetFont('Arial', 'B', 16);
    $pdf->SetTextColor(255, 255, 255);
    $pdf->SetFillColor(0, 0, 0);
    $pdf->Cell(0, 10, 'Facility Booking Receipt', 0, 1, 'C', true);

    $pdf->SetFont('Arial', '', 12);
    $pdf->SetTextColor(0, 0, 0);
    $pdf->Ln(10);
    $pdf->Cell(0, 10, 'Booking Details', 0, 1, 'C');

    $pdf->Cell(50, 10, 'Name:', 1);
    $pdf->Cell(0, 10, $booking['full_name'], 1, 1);

    $pdf->Cell(50, 10, 'Facility:', 1);
    $pdf->Cell(0, 10, $facility_name, 1, 1);

    $pdf->Cell(50, 10, 'Booking Date:', 1);
    $pdf->Cell(0, 10, $booking['booking_date'], 1, 1);

    $pdf->Cell(50, 10, 'Booking Time:', 1);
    $pdf->Cell(0, 10, $booking['booking_time'], 1, 1);

    $pdf->Cell(50, 10, 'Booking Duration:', 1);
    $pdf->Cell(0, 10, $booking['booking_duration'] . ' hours', 1, 1);

    $pdf->Cell(50, 10, 'Amount Paid:', 1);
    $pdf->Cell(0, 10, 'RM ' . number_format((float)$booking['fees'], 2), 1, 1);

    $pdf->Ln(10);
    $pdf->Cell(0, 10, 'Please use the QR code below to access the facility:', 0, 1, 'C');

    $qrData = "Booking Confirmation for " . $facility_name . " by " . $booking['full_name'] .
        " on " . $booking['booking_date'] . " at " . $booking['booking_time'];

    if ($booking['type'] === 'nonresident') {
        $qrData .= ". Please use this QR code to enter the condo and the facility.";
    } else {
        $qrData .= ". Please use this QR code to enter the facility.";
    }

    $qrFilePath = generateQRCode($qrData, 'qrcode_' . $booking['booking_id'] . '.png');
    $pdf->Image($qrFilePath, 80, $pdf->GetY(), 50, 50);

    $tempDir = __DIR__ . '/temp/';
    if (!file_exists($tempDir)) mkdir($tempDir, 0777, true);

    $receiptPath = $tempDir . 'receipt_' . $booking['booking_id'] . '.pdf';
    $pdf->Output('F', $receiptPath);

    return $receiptPath;
}

/**
 * =========================================================
 * ✅ Fetch booking + facility
 * =========================================================
 */
function fetchBookingDetails($conn, $booking_id, $facility_id) {
    $stmt = $conn->prepare("
        SELECT 
            b.id AS booking_id,
            b.register_id,
            b.facility_id,
            b.booking_duration,
            b.booking_date,
            b.booking_time,
            b.status,
            b.type,
            b.fees,
            r.email,
            r.full_name,
            f.name AS facility_name,
            f.resident_price,
            f.nonresident_price
        FROM booking b
        JOIN register r ON b.register_id = r.id
        JOIN Facility f ON b.facility_id = f.id
        WHERE b.id = :booking_id AND b.facility_id = :facility_id
        LIMIT 1
    ");
    $stmt->bindParam(':booking_id', $booking_id, PDO::PARAM_INT);
    $stmt->bindParam(':facility_id', $facility_id, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

/**
 * =========================================================
 * ✅ Process payment / confirm
 * =========================================================
 * 规则：
 * - resident：不收费，直接 confirmed
 * - nonresident：收费（admin facility nonresident_price），插入 payment 后 confirmed
 * - booking.status 统一用：booked / confirmed / cancelled
 */
function processPayment($conn, $booking_id, $facility_id) {
    global $paymentMessage;

    $payment_method = $_POST['payment_method'] ?? 'N/A';

    $booking = fetchBookingDetails($conn, $booking_id, $facility_id);

    if (!$booking) {
        $paymentMessage = "No valid booking found.";
        return;
    }

    // ✅ 只允许 booked 才能处理（避免重复 confirm / 重复 payment）
    if ($booking['status'] !== 'booked') {
        $paymentMessage = "This booking has already been processed (status: {$booking['status']}).";
        return;
    }

    try {
        $conn->beginTransaction();

        // ✅ resident：RM0，直接 confirmed（不插 payment）
        if ($booking['type'] === 'resident') {

            // (可选) 写回 fees=0
            $upd = $conn->prepare("UPDATE booking SET status='confirmed', fees=0.00 WHERE id=:id");
            $upd->bindParam(':id', $booking['booking_id'], PDO::PARAM_INT);
            $upd->execute();

            $conn->commit();

            $paymentMessage = "Resident booking confirmed. No payment required.";

            // ✅ send receipt + qr (RM0)
            $booking['fees'] = 0.00;
            $receiptPath = generateReceipt($booking, $booking['facility_name']);

            $emailBody = "Dear {$booking['full_name']}, your resident booking is confirmed. No payment is required. 
            Please find the attached receipt and QR code for entry.";

            sendEmail($booking['email'], "Booking Confirmation (No Payment Required)", $emailBody, [$receiptPath]);
            return;
        }

        // ✅ nonresident：收费 = admin facility nonresident_price
        $amount = (float)$booking['nonresident_price'];

        // 如果你要按 duration 收费，开这行：
        // $amount = $amount * (int)$booking['booking_duration'];

        if ($amount <= 0) {
            $conn->rollBack();
            $paymentMessage = "Payment amount is invalid. Please contact admin.";
            return;
        }

        // ✅ insert payment
        $stmt = $conn->prepare("
            INSERT INTO payment (booking_id, amount, payment_method, type)
            VALUES (:booking_id, :amount, :payment_method, :type)
        ");
        $stmt->bindParam(':booking_id', $booking['booking_id'], PDO::PARAM_INT);
        $stmt->bindParam(':amount', $amount);
        $stmt->bindParam(':payment_method', $payment_method);
        $stmt->bindParam(':type', $booking['type']);
        $stmt->execute();

        // ✅ 关键：付款后 booking.status 也改成 confirmed（不要用 paid）
        $upd = $conn->prepare("UPDATE booking SET status='confirmed', fees=:fees WHERE id=:id");
        $upd->bindParam(':id', $booking['booking_id'], PDO::PARAM_INT);
        $upd->bindParam(':fees', $amount);
        $upd->execute();

        $conn->commit();

        $paymentMessage = "Payment successful.";

        // ✅ send receipt + qr
        $booking['fees'] = $amount;
        $receiptPath = generateReceipt($booking, $booking['facility_name']);

        $emailBody = "Dear {$booking['full_name']}, your payment of RM " . number_format($amount, 2) .
            " for the facility booking has been received. Please find the attached receipt and QR code for entry.";

        sendEmail($booking['email'], "Payment Confirmation", $emailBody, [$receiptPath]);

    } catch (Exception $e) {
        if ($conn->inTransaction()) $conn->rollBack();
        $paymentMessage = "Error processing request. Please try again.";
        error_log("processPayment error: " . $e->getMessage());
    }
}

/**
 * =========================================================
 * ✅ Handle POST submit
 * =========================================================
 */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    processPayment($conn, $booking_id, $facility_id);
}

/**
 * =========================================================
 * ✅ Load booking for UI
 * =========================================================
 */
$bookingInfo = fetchBookingDetails($conn, $booking_id, $facility_id);
$bookingType = $bookingInfo['type'] ?? 'nonresident';
$displayName = $bookingInfo['full_name'] ?? '';
?>
<!DOCTYPE html>
<html>
<head>
    <title>Payment Page</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            margin: 0;
        }
        h1 { color: #333; text-align: center; font-size: 2em; }
        .payment-container {
            text-align: center;
            margin-top: 20px;
            padding: 10px;
            border: 1px solid #ccc;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            max-width: 420px;
            width: 100%;
        }
        form {
            margin-bottom: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        .input-field {
            width: 300px;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        input[type="submit"], .payment-button {
            background-color: black;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 1em;
        }
        input[type="submit"]:hover, .payment-button:hover { background-color: DodgerBlue; }
        .payment-message {
            color: black;
            font-weight: bold;
            text-align: center;
            margin-top: 10px;
        }
        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 10px 0;
            margin-top: auto;
            width: 100%;
        }
        .content-wrapper {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            flex: 1;
        }
        .hint { font-size: 0.95em; color: #666; margin-bottom: 10px; }
    </style>
    <script>
        function redirectAfterSuccess() {
            setTimeout(function() {
                window.location.href = 'resident_nonresident.php';
            }, 3000);
        }
    </script>
</head>
<body>
<div class="content-wrapper">
    <h1><?php echo ($bookingType === 'resident') ? "Confirm Booking" : "Make a Payment"; ?></h1>

    <div class="payment-container">
        <?php if (!$bookingInfo): ?>
            <p class="payment-message">Booking not found.</p>

        <?php elseif ($bookingType === 'resident'): ?>
            <p class="hint">Resident booking detected. No payment is required.</p>

            <form method="post" action="">
                <input type="hidden" name="action" value="confirm_resident">
                <input type="submit" value="Confirm Booking (No Payment)">
            </form>

        <?php else: ?>
            <p class="hint">Nonresident booking. Fee will follow admin facility price.</p>

            <form method="post" action="">
                <input type="hidden" name="action" value="pay">

                <label for="payment_full_name">Full Name:</label>
                <input type="text" id="payment_full_name" name="payment_full_name" class="input-field"
                       required value="<?php echo htmlspecialchars($displayName); ?>">

                <label for="payment_method">Payment Method:</label>
                <select name="payment_method" id="payment_method" class="input-field" required>
                    <option value="Credit Card">Credit Card</option>
                    <option value="Touch 'n Go">Touch 'n Go</option>
                </select>

                <input type="submit" value="Pay">
            </form>
        <?php endif; ?>

        <?php if ($paymentMessage): ?>
            <p class="payment-message"><?php echo htmlspecialchars($paymentMessage); ?></p>

            <?php if ($paymentMessage === "Payment successful." || $paymentMessage === "Resident booking confirmed. No payment required."): ?>
                <script>redirectAfterSuccess();</script>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>

<footer>
    <p>&copy; <?php echo date('Y'); ?> Condominium Facilities Booking System. All rights reserved. | Created by JiaJie</p>
</footer>
</body>
</html>